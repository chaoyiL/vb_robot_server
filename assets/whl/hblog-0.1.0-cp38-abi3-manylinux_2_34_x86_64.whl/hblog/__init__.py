try:
    import rb_python
    import sys

    sys.modules["_hblog"] = rb_python.hblog
    from _hblog import *
except:
    from .hblog import *
